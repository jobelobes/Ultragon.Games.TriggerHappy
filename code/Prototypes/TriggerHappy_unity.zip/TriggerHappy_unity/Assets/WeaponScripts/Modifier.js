var timestamp;
var duration = 10;
var type = 1;
var victim;
var ModifierPosition;

private var activated = false;


function AddEffect(type)
{
	switch(type)
	{
		case 1:
			Debug.Log("Adding explosion force to " + gameObject.name);
			victim.rigidbody.AddExplosionForce(10, ModifierPosition, 5, 10);
			break;
		case 0:
			Debug.Log("Adding drag to " + gameObject.name);
			gameObject.rigidbody.drag = 1000;
			break;
	}
}

function RemoveEffect(type)
{
	switch(type)
	{
		case 1:
			
			break;
		case 0:
			Debug.Log("Removing drag from " + gameObject.name);
			gameObject.rigidbody.drag = 0;
			break;
	}
}

function Start()
{
	timestamp = Time.time;
}

function Update()
{
	if(activated)
	{
		if(Time.time > (timestamp + duration))
		{
			RemoveEffect(type);
			Destroy(this);
			return;
		}
	}
	else
	{
		activated = true;
		AddEffect(type);
	}
}