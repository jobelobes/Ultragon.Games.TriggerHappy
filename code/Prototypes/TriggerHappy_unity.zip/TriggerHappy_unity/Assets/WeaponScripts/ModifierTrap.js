var cooldown = 10;
var initialize = 1;
var MaxActivations = 1;
var Radius = 3;
var Owner : GameObject;

private var count = 0;
private var state = 0;
private var lastChanged = -10;

function Deactivate()
{
	if (state != 2 && Time.time > (lastChanged + cooldown))
	{
		state = 2;
		Debug.Log("Deactivated", this);
		
		if(count <= 0)
		{
			Debug.Log("Destroyed", this);
			Destroy(gameObject);
		}
	}
}
function Activate()
{
	if (state != 2 || Time.time < (lastChanged + cooldown))
		return;
	
	var colliders : Collider[] = Physics.OverlapSphere (transform.position, Radius);
	if(colliders.length > 0)
	{
		for (var hit in colliders) 
		{
			if( hit == Owner)
				continue;
			else if (hit && hit.rigidbody &&  hit.gameObject != ModifierTrap && count > 0)
			{
				var modifier = hit.gameObject.AddComponent("Modifier");
				modifier.ModifierPosition = transform.position;
				modifier.victim = hit;
				state = 3;
			}
		}
		
		if(state == 3)
		{
			count--;
			lastChanged = Time.time;
			Debug.Log("Activated", this);
		}
	}
}

function Start()
{
	state = 0;
	count = 0;
	lastChanged = Time.time;
}

function Update()
{
	switch(state)
	{
		case 0:
			Debug.Log("Initializing", this);
			state = 1;
			break;
		case 1:
			if (Time.time > (lastChanged + initialize))
			{
				count = MaxActivations;
				state = 2;
				lastChanged = Time.time - cooldown;
				Debug.Log("Initialized", this);
			}
			break;
		case 2:
			Activate();
			break;
		case 3:
			Deactivate();
			break;
	}
}