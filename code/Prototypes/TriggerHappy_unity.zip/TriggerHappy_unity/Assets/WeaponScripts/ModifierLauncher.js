var projectile : ModifierTrap;
var initialSpeed = 20.0;
var reloadTime = 1.0;
var ammoCount = 20;

private var lastShot = -10.0;

function Fire ()
{
	// Did the time exceed the reload time?
	if (Time.time > (reloadTime + lastShot) && ammoCount > 0)
	{
		// create a new projectile, use the same position and rotation as the Launcher.
		var modifier : ModifierTrap = Instantiate (projectile, transform.position, Quaternion(0, transform.rotation.y, 0, transform.rotation.w));
		modifier.Owner = gameObject;
		modifier.Radius = 1;
		
		// Give it an initial forward velocity. The direction is along the z-axis of
		// the missile launcher's transform.
		modifier.rigidbody.velocity = transform.TransformDirection(Vector3 (0, 0, initialSpeed));
		
		this.lastShot = Time.time;
		//this.ammoCount--;
	}
}